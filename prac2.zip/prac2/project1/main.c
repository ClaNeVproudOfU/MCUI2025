#include <8051.h> 
void main() 
{ 
unsigned char i,j;
unsigned char massiv [11]= 
{ 
0xC0,
0xF9, 
0xA4, 
0xB0, 
0x99, 
0x92, 
0x82, 
0xF8, 
0x80, 
0x90, 
0xFF 
}; 

P3=0;
while(P3==0);
P2=massiv [10];
for(i=10;i>0;i-=1)
{ 
P2=massiv[i-1];
for(j=0;j<100;j++) 

continue;

P2=massiv[3];
for(j=0;j<100;j++) 

continue;

} 
P2=massiv[10];
P3=0;
}