#include <8051.h> 

void tput(unsigned char c1) 
{ 
SBUF=c1;  
while(!TI); 
TI=0;  
}
void main() 
{ 

char z; 
int i; 

unsigned char *src = (unsigned char *)0x30;
src[0] = 'a';
src[1] = 'b';
src[2] = 'c';
src[3] = 'd';
src[4] = 'e';
src[5] = 'f';
src[6] = 'g';
src[7] = 'h';
src[8] = 'j';
src[9] = 'k';
src[10] = 'l';
src[11] = 'm';
src[12] = 'n';
src[13] = 'o';
src[14] = 'p';
src[15] = 'r';
src[16] = 's';
src[17] = 't';
src[18] = 'u';
src[19] = 'w';
TMOD= 0x20;
TH1= 0x0F4;
PCON=0x0; 
TR1=0x1;
for(i=0; i<20; i++) 
{ 
ACC=src[i];  
SCON = 0x40; 
tput (src[i]); 
} 
while(1){} 
}