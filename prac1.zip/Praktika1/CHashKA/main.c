#include <8051.h>   

void main()     
{ 
int i; 
char xdata *ptr;   
char test, nabor; 
nabor = 0x55;
ptr = (char xdata *) 0x400;
P1=0x00;
for(i=0; i<1024;i++)
{
if(i==15)
{
*ptr=0x13;
}
else{ 
*ptr=nabor; 
}   
test=*ptr;    
if(test!=nabor) 
{ 
P1=0x01;      
} 
ptr++; 
} 
} 
