#include <htc.h> 
unsigned int tmpCnt; 
void imp(unsigned int cnt) 
{ 
do{ }while(TF2==0); 
TF2 = 0; 
P10 = 1; 
while (cnt != 0)cnt--; 
P10 = 0; 
} 
void main() 
{ 
tmpCnt = 616;
  
P1 = 0xFE; 
RCAP2H = 0x150B8; 
RCAP2L = 0x150B8; 
 
T2CON &= 0xFC; 
ET2 = 1; 
EA = 1;  
T2CON |= 0x4;

while(1) 
{ 
P0=0;
if((P00 == 1 && P01 == 1) || (P00 == 0 && P01 == 0))
{
while(P00);
}
else if (P01 ==1)
{
tmpCnt = 910;
}
else if(P00 ==1)
{
tmpCnt = 616;
}
imp(tmpCnt); 
} 
} 