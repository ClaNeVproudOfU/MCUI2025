#include <8051.h>  
void msec (int x) 
 
{ 
while(x-->0)  
{ 
TH0 = (-2500)>>8;

TL0=-2500;  
 
TR0=1;   
do; 
while(TF0==0);  
TF0=0;  
TR0=0;  
} 
} 
void main()  
{ 
int i; 
unsigned char array[7]; 
TMOD=0x1;  
array[0]=0x0;  
array[1] = 0x4;  
array[2]=0x8; 
array[3] = 0x10; 
array[4]=0x20; 
array[5]=0x81; 
array[6]=0x42; 
 
P1=array[0];
msec(1); 
for(i=1;i<7;i++)  
{ 
P1=array[i];  
if(i<6)
{ 
msec(4);
}
else if(i==6)
{
msec(4);
} 
else
{
msec(6);
}
} 
while(1); 
}