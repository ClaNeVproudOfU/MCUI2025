#include <8051.h>
void msec (int x) 
{ 
while(x-->0)  
{ 
TH0 = (-200)>>8;

TL0=-200;  
 
TR0=1;   
do; 
while(TF0==0);  
TF0=0;  
TR0=0;  
} 
} 
void vol0_357()
{
TH0 = (-230)>>8;

TL0=-230;  
 
TR0=1;   

while(TF0==0)
{
P2+=5;
}
TF0=0;  
TR0=0;  
}
void vol25_0()
{
TH0 = (-230)>>8;

TL0=-230;  
 
TR0=1;   

while(TF0==0)
{
if(P2!=1)
{
P2-=7;
}
}
TF0=0;  
TR0=0;  
}
void main()
{
TMOD = 0x1;
P2 = 0x0;
msec(1);
vol0_357();
P2 = 0xBF;
P2 = 0xFF;
msec(1);
P2 = 0x7F;
vol25_0();
P2 = 0;
msec(1);


}
